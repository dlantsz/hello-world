<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Rates</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <script src="js/wow.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <link rel="stylesheet" href="<?=base_url('css/style.css');?>">
    <script src="<?=base_url('js/jquery.js')?>"></script>

    
</head>
<body style="background-color:#FFE6AF;">




<nav class="navbar navbar-expand-lg p-4">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?= base_url('airexport');?>">
    <img src="<?=base_url('images/logo.png');?>" style="width:80%" alt="Our Rate" class="animate__animated animate__fadeIn">
    </a>
  </div>
</nav>
<div class="container-fluid">








